#include <iostream>
#include <vector>
#include <limits>
#include <sstream>
#include <fstream>

#include <iostream>
#include <vector>

class MemoryManagement {
private:
    std::vector<int> memoria;
    std::vector<int> tamanosParticiones;

public:
    // Constructor que inicializa la memoria
    MemoryManagement(int tamanoTotal, const std::vector<int>& particiones) : memoria(tamanoTotal, -1), tamanosParticiones(particiones) {}

// Función para asignar memoria utilizando el algoritmo Best-fit
bool memAllocBestFit(int procesoID, int tamano) {
    int mejorIndice = -1;
    int menorDiferencia = std::numeric_limits<int>::max();

    int espacioLibre = 0;
    for (int i = 0; i < memoria.size(); i++) {
        if (memoria[i] == -1) { // Si el espacio está libre
            espacioLibre++;
            if (i == memoria.size() - 1 || memoria[i + 1] != -1) { // Final del espacio libre
                if (espacioLibre >= tamano && espacioLibre - tamano < menorDiferencia) {
                    mejorIndice = i - espacioLibre + 1;
                    menorDiferencia = espacioLibre - tamano;
                }
                espacioLibre = 0;
            }
        } else {
            espacioLibre = 0;
        }
    }

    if (mejorIndice != -1) {
        for (int i = 0; i < tamano; i++) {
            memoria[mejorIndice + i] = procesoID;
        }
        return true;
    }

    return false; // No hay suficiente espacio libre
}
bool memAllocFirstFit(int procesoID, int tamano) {
        // Aquí implementamos el algoritmo First-fit
        int espacioLibre = 0;
        for (int i = 0; i < memoria.size(); i++) {
            if (memoria[i] == -1) { // Si el espacio está libre
                espacioLibre++;
                if (espacioLibre == tamano) { // Si encontramos un espacio que se ajusta
                    for (int j = i - tamano + 1; j <= i; j++) {
                        memoria[j] = procesoID;
                    }
                    return true;
                }
            } else {
                espacioLibre = 0;
            }
        }
        return false; // No hay suficiente espacio libre
    }

// Función para asignar memoria utilizando el algoritmo Worst-fit
bool memAllocWorstFit(int procesoID, int tamano) {
    int peorIndice = -1;
    int mayorDiferencia = 0;

    int espacioLibre = 0;
    for (int i = 0; i < memoria.size(); i++) {
        if (memoria[i] == -1) { // Si el espacio está libre
            espacioLibre++;
            if (i == memoria.size() - 1 || memoria[i + 1] != -1) { // Final del espacio libre
                if (espacioLibre >= tamano && espacioLibre - tamano > mayorDiferencia) {
                    peorIndice = i - espacioLibre + 1;
                    mayorDiferencia = espacioLibre - tamano;
                }
                espacioLibre = 0;
            }
        } else {
            espacioLibre = 0;
        }
    }

    if (peorIndice != -1) {
        for (int i = 0; i < tamano; i++) {
            memoria[peorIndice + i] = procesoID;
        }
        return true;
    }

    return false; // No hay suficiente espacio libre
}

};
#include <fstream>
#include <sstream>
#include <vector>

class Reader {
public:
    static std::vector<std::string> readFromFile(const std::string& filename) {
        std::vector<std::string> lines;
        std::ifstream file(filename);
        std::string line;

        while (getline(file, line)) {
            if (!line.empty() && line[0] != '#') { // Ignorar líneas vacías y comentarios
                lines.push_back(line);
            }
        }
        file.close();
        return lines;
    }
};


int main() {
    std::vector<std::string> lines = Reader::readFromFile("Entrada1.txt");

    // Parsear las líneas leídas
    int tamanoMemoria = std::stoi(lines[0]);
    int numParticiones = std::stoi(lines[1]);
    std::vector<int> particiones;
    std::stringstream ss(lines[2]);
    for (int i = 0; i < numParticiones; i++) {
        int part;
        ss >> part;
        particiones.push_back(part);
    }

    MemoryManagement gestor(tamanoMemoria, particiones);

    int algoritmo = std::stoi(lines[3]);
    for (int i = 4; i < lines.size(); i++) {
        std::stringstream ssp(lines[i]);
        std::string proceso;
        int id, tamano;
        ssp >> proceso >> id >> tamano;

        bool asignado = false;
        switch (algoritmo) {
            case 1:
                asignado = gestor.memAllocFirstFit(id, tamano);
                break;
            case 2:
                asignado = gestor.memAllocBestFit(id, tamano);
                break;
            case 3:
                asignado = gestor.memAllocWorstFit(id, tamano);
                break;
        }

        if (asignado) {
            std::cout << "Proceso " << id << " de tamaño " << tamano << " asignado correctamente." << std::endl;
        } else {
            std::cout << "No se pudo asignar memoria para el proceso " << id << std::endl;
        }
    }

    return 0;
}
