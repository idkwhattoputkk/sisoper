#include <iostream>
#include <vector>

// Estructura para representar un segmento de memoria
struct Segmento {
    int idProceso;  // ID del proceso al que pertenece el segmento (-1 si está libre)
    int tamaño;     // Tamaño del segmento
};

// Estructura para representar un proceso
struct Proceso {
    int id;
    int tamaño;
};

class SimuladorSegmentación {
private:
    std::vector<Segmento> memoriaSegmentada;

    // Función auxiliar para encontrar un segmento libre usando First-Fit
    int encontrarSegmentoLibre(int tamañoRequerido) {
        for (size_t i = 0; i < memoriaSegmentada.size(); ++i) {
            if (memoriaSegmentada[i].idProceso == -1 && memoriaSegmentada[i].tamaño >= tamañoRequerido) {
                return i;
            }
        }
        return -1;  // No se encontró un segmento libre adecuado
    }

public:
    SimuladorSegmentación(int tamañoMemoria) {
        memoriaSegmentada.push_back({-1, tamañoMemoria});  // Al inicio, toda la memoria está libre
    }

    bool asignarMemoria(int procesoID, int tamaño) {
        int idx = encontrarSegmentoLibre(tamaño);
        if (idx != -1) {
            memoriaSegmentada[idx].idProceso = procesoID;
            memoriaSegmentada[idx].tamaño -= tamaño;
            if (memoriaSegmentada[idx].tamaño > 0) {
                // Si hay espacio sobrante en el segmento, se crea un nuevo segmento libre
                memoriaSegmentada.insert(memoriaSegmentada.begin() + idx + 1, {-1, memoriaSegmentada[idx].tamaño - tamaño});
                memoriaSegmentada[idx].tamaño = tamaño;
            }
            return true;
        }
        return false;
    }

    void liberarMemoria(int procesoID) {
        for (size_t i = 0; i < memoriaSegmentada.size(); ++i) {
            if (memoriaSegmentada[i].idProceso == procesoID) {
                memoriaSegmentada[i].idProceso = -1;
                // Combinar segmentos libres adyacentes
                if (i > 0 && memoriaSegmentada[i - 1].idProceso == -1) {
                    memoriaSegmentada[i - 1].tamaño += memoriaSegmentada[i].tamaño;
                    memoriaSegmentada.erase(memoriaSegmentada.begin() + i);
                    i--;
                }
                if (i < memoriaSegmentada.size() - 1 && memoriaSegmentada[i + 1].idProceso == -1) {
                    memoriaSegmentada[i].tamaño += memoriaSegmentada[i + 1].tamaño;
                    memoriaSegmentada.erase(memoriaSegmentada.begin() + i + 1);
                }
            }
        }
    }

    void imprimirEstadoMemoria() {
        std::cout << "Estado de la memoria segmentada:" << std::endl;
        for (const Segmento &s : memoriaSegmentada) {
            std::cout << (s.idProceso == -1 ? "Libre" : "Ocupado") << " - Tamaño: " << s.tamaño;
            if (s.idProceso != -1) std::cout << ", Proceso ID: " << s.idProceso;
            std::cout << std::endl;
        }
    }
};

int main() {
    SimuladorSegmentación simulador(100);  // Memoria de tamaño 100

    // Asignar espacio a procesos
    simulador.asignarMemoria(1, 30);
    simulador.asignarMemoria(2, 40);
    simulador.asignarMemoria(3, 15);

    // Liberar espacio de procesos
    simulador.liberarMemoria(1);

    // Imprimir estado de la memoria
    simulador.imprimirEstadoMemoria();
    return 0;
}
