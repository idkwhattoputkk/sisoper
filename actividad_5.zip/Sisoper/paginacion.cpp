#include <iostream>
#include <vector>

// Estructura para representar una página de memoria
struct Pagina {
    int idProceso;  // ID del proceso al que pertenece la página (-1 si está libre)
};

// Estructura para representar un proceso
struct Proceso {
    int id;
    int tamaño;
    std::vector<int> paginasAsignadas;  // Lista de páginas asignadas al proceso
};

class SimuladorPaginación {
private:
    int tamañoMemoria;
    int tamañoPagina;
    std::vector<Pagina> memoriaPaginada;
    std::vector<Proceso> procesos;

public:
    SimuladorPaginación(int tamaño, int tamañoPag) : tamañoMemoria(tamaño), tamañoPagina(tamañoPag) {
        // Inicializar la memoria con páginas vacías
        int numPaginas = tamañoMemoria / tamañoPagina;
        memoriaPaginada.resize(numPaginas, {-1});
    }

    bool asignarMemoria(int procesoID, int tamaño) {
        int paginasNecesarias = (tamaño + tamañoPagina - 1) / tamañoPagina;  // Redondear hacia arriba
        std::vector<int> paginasObtenidas;

        // Buscar páginas libres
        for (size_t i = 0; i < memoriaPaginada.size() && paginasNecesarias > 0; ++i) {
            if (memoriaPaginada[i].idProceso == -1) {
                memoriaPaginada[i].idProceso = procesoID;
                paginasObtenidas.push_back(i);
                paginasNecesarias--;
            }
        }

        if (paginasNecesarias == 0) {
            // Añadir el proceso a la lista y guardar las páginas asignadas
            procesos.push_back({procesoID, tamaño, paginasObtenidas});
            return true;
        } else {
            // No hay suficiente memoria, revertir la asignación
            for (int pagina : paginasObtenidas) {
                memoriaPaginada[pagina].idProceso = -1;
            }
            return false;
        }
    }

    void liberarMemoria(int procesoID) {
        for (size_t i = 0; i < memoriaPaginada.size(); ++i) {
            if (memoriaPaginada[i].idProceso == procesoID) {
                memoriaPaginada[i].idProceso = -1;
            }
        }
        procesos.erase(std::remove_if(procesos.begin(), procesos.end(),
                                      [procesoID](const Proceso &p) { return p.id == procesoID; }),
                       procesos.end());
    }

    void imprimirEstadoMemoria() {
        std::cout << "Estado de la memoria paginada:" << std::endl;
        for (size_t i = 0; i < memoriaPaginada.size(); ++i) {
            std::cout << "Página " << i << ": " << (memoriaPaginada[i].idProceso == -1 ? "Libre" : "Ocupada") << " - Proceso ID: " << memoriaPaginada[i].idProceso << std::endl;
        }

        std::cout << "\nProcesos en memoria:" << std::endl;
        for (const Proceso &p : procesos) {
            std::cout << "Proceso ID: " << p.id << ", Tamaño: " << p.tamaño << ", Páginas: ";
            for (int pagina : p.paginasAsignadas) {
                std::cout << pagina << " ";
            }
            std::cout << std::endl;
        }
    }
};

int main() {
    int tamañoMemoria = 100; // Tamaño de la memoria paginada
    int tamañoPagina = 20;   // Tamaño de cada página

    SimuladorPaginación simulador(tamañoMemoria, tamañoPagina);

    // Asignar espacio a procesos
    simulador.asignarMemoria(1, 30);
    simulador.asignarMemoria(2, 40);
    simulador.asignarMemoria(3, 15);

    // Liberar espacio de procesos
    simulador.liberarMemoria(1);

    // Imprimir estado de la memoria
    simulador.imprimirEstadoMemoria();
    return 0;
}
